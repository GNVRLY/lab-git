rootProject.name = "rest-service"
