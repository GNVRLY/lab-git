/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	  https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.restservice;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.resttestclient.autoconfigure.AutoConfigureRestTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.client.RestTestClient;

@SpringBootTest
@AutoConfigureRestTestClient
public class GreetingControllerTests {

	@Autowired
	private RestTestClient restTestClient;

	@Test
	public void noParamGreetingShouldReturnDefaultMessage() throws Exception {

		this.restTestClient.get().uri("/greeting")
				.exchange()
				.expectStatus().isOk()
				.expectBody()
				.jsonPath("$.content").isEqualTo("Hello, World!");
	}

	@Test
	public void paramGreetingShouldReturnTailoredMessage() throws Exception {

		this.restTestClient.get()
				.uri(uri -> uri.path("/greeting").queryParam("name", "Spring Community").build())
				.exchange()
				.expectStatus().isOk()
				.expectBody()
				.jsonPath("$.content").isEqualTo("Hello, Spring Community!");
	}

}
